"use client";

import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { ExternalLinks } from "@/components/targets/ExternalLinks";
import { TargetApartmentSearch } from "@/components/targets/TargetApartmentSearch";
import { useRealtyStore } from "@/lib/clientStore";
import type { Apartment } from "@/types/apartment";

export default function TargetsPage() {
  const store = useRealtyStore();

  function addTarget(apartment: Apartment) {
    if (store.targets.some((x) => x.name === apartment.name && x.address === apartment.address)) return;
    store.setApartments([...store.apartments, apartment]);
  }

  function removeTarget(id: string) {
    store.setApartments(store.apartments.filter((x) => x.id !== id));
  }

  return (
    <AppShell>
      <div className="mb-8">
        <p className="text-sm font-semibold text-blue-600">Targets</p>
        <h1 className="text-3xl font-black">대상아파트 관리</h1>
        <p className="mt-2 text-slate-600">관심아파트 별도 개념 없이, 추가한 아파트는 모두 분석 대상입니다.</p>
      </div>
      <TargetApartmentSearch apartments={store.apartments} onAdd={addTarget} />
      <div className="card mt-6 p-5">
        <h2 className="text-lg font-black">대상아파트 목록</h2>
        <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200">
          <table className="table w-full">
            <thead><tr><th>지역</th><th>아파트명</th><th>주소</th><th>외부조회</th><th>기능</th></tr></thead>
            <tbody>
              {store.targets.map((apt) => (
                <tr key={apt.id}>
                  <td>{apt.region}</td>
                  <td className="font-bold">{apt.name}</td>
                  <td>{apt.address}</td>
                  <td><ExternalLinks apartmentName={apt.name} /></td>
                  <td className="space-x-2"><Link className="btn-secondary" href={`/targets/${apt.id}`}>상세</Link><button className="btn-secondary" onClick={() => removeTarget(apt.id)}>삭제</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
