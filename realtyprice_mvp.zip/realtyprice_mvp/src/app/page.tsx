import Link from "next/link";
import { BarChart3, Building2, Database, Gauge, LineChart, Search, ShieldCheck } from "lucide-react";

const features = [
  ["분석대상 관리", "지역/아파트명 검색 후 대상아파트 추가", Search],
  ["비교단지 선택", "인근 기준 설정 후 직접 선택·가중치 반영", Building2],
  ["동호수 등급 보정", "S/A/B/C/D 등급으로 사례가격 보정", ShieldCheck],
  ["매물소진추정", "저가매물 소진율로 상승 신호 포착", Gauge],
  ["예상 매매가 산출", "권장 매각호가·방어가격 자동 계산", LineChart],
  ["CSV·수기 입력", "자동 수집이 어려워도 데이터 누적 가능", Database]
] as const;

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-white">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <div className="font-bold text-slate-900">분양권 매각판단 대시보드</div>
        <nav className="hidden items-center gap-6 text-sm text-slate-600 md:flex">
          <a href="#features">기능</a>
          <a href="#workflow">프로세스</a>
          <a href="#model">가격모델</a>
          <Link className="btn-primary" href="/dashboard">지금 시작하기</Link>
        </nav>
      </header>

      <section className="mx-auto grid max-w-7xl gap-10 px-6 py-14 lg:grid-cols-[1fr_1.05fr] lg:items-center">
        <div>
          <div className="mb-4 inline-flex rounded-full bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700">프론트 중심 MVP</div>
          <h1 className="text-4xl font-black tracking-tight text-slate-950 md:text-6xl">
            분양권, 지금 얼마에<br />내놓아야 할까?
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
            실거래가·전세가·호가·매물소진추정·동호수 등급을 반영해 권장 매각호가와 예상 체결가를 한눈에 제시합니다.
          </p>
          <div className="mt-8 flex gap-3">
            <Link className="btn-primary" href="/targets">대상아파트 추가</Link>
            <Link className="btn-secondary" href="/dashboard">데모 보기</Link>
          </div>
        </div>

        <div className="card p-5">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500">대상아파트</p>
              <h2 className="text-xl font-bold">오산역 금강펜테리움</h2>
            </div>
            <span className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-bold text-emerald-700">상승예상</span>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            {[
              ["권장 매각호가", "5.35억"],
              ["예상 체결가", "5.05~5.25억"],
              ["상승가능성", "72점"]
            ].map(([label, value]) => (
              <div key={label} className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs text-slate-500">{label}</p>
                <p className="mt-2 text-xl font-black text-slate-900">{value}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 h-44 rounded-2xl bg-gradient-to-br from-blue-50 to-teal-50 p-4">
            <BarChart3 className="mb-4 text-blue-600" />
            <div className="flex h-24 items-end gap-3">
              {[40, 55, 52, 68, 74, 72].map((h, i) => (
                <div key={i} className="flex-1 rounded-t-xl bg-blue-500/80" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-7xl px-6 py-14">
        <h2 className="text-center text-3xl font-black">핵심 기능</h2>
        <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {features.map(([title, desc, Icon]) => (
            <div key={title} className="card p-6">
              <Icon className="mb-4 text-blue-600" />
              <h3 className="text-lg font-bold">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="workflow" className="mx-auto max-w-7xl px-6 py-14">
        <div className="card p-8">
          <h2 className="text-2xl font-black">분석 프로세스</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-5">
            {["대상아파트 추가", "인근 기준 설정", "비교단지 선택", "실거래·호가 입력", "매각호가 제안"].map((step, i) => (
              <div key={step} className="rounded-2xl bg-slate-50 p-4 text-center">
                <div className="mx-auto mb-3 flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-sm font-bold text-white">{i + 1}</div>
                <p className="text-sm font-semibold">{step}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="model" className="mx-auto max-w-7xl px-6 py-14">
        <div className="card bg-slate-950 p-8 text-white">
          <h2 className="text-2xl font-black">가격 산정 로직</h2>
          <p className="mt-4 text-slate-300">
            예상 매매가 = 비교단지 보정 실거래가 40% + 현재 매매호가 20% + 전세기반 하방가 15% + 매물소진속도 15% + 분양가 대비 프리미엄 5% + 거시환경 5%
          </p>
        </div>
      </section>

      <footer className="border-t border-slate-200 px-6 py-10 text-center text-sm text-slate-500">
        © 2026 realtyprice. 데이터 기반 분양권 매각판단 MVP.
      </footer>
    </main>
  );
}
